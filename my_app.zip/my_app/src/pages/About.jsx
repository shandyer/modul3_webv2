import React from "react";
import "./styles.css"; // Import CSS file

const About = () => {
  return (
    <div className="text-box">
      {" "}
      {/* Tambahkan class "text-box" */}
      <h1>About Us Page</h1>
      {/* Isi konten About Us di sini */}
    </div>
  );
};

export default About;
